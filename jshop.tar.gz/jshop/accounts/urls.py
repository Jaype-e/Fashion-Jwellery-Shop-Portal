from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.homepage, name='homepage'),
    url(r'^login$', views.login, name='loginpage'),
    url(r'^confirm$', views.confirm, name='loginpage'),
    url(r'^signup$', views.signup, name='signuppage'),
    url(r'^logout$', views.logout, name='logout'),
    url(r'^profile$', views.profile, name='profile'),
    url(r'^profile/orders$', views.profile_orders, name='profile'),
    url(r'^profile/edit$', views.profile_edit, name='profile'),
    url(r'^profile/review$', views.profile_review, name='profile'),
    url(r'^profile/pay$', views.pay, name='profile')
]