from django.shortcuts import render, redirect
from django.db import connection
import hashlib

salt = 'i am the chacha'.encode('utf-8')

def read_file(filename):
    with open(filename, 'rb') as f:
        photo = f.read()
    return photo


def write_file(data, filename):
    with open(filename, 'wb') as f:
        f.write(data)


# Create your views here.
def start_user_session(request, user_id, user_class):
    request.session["user_mail_id"] = user_id
    request.session["customer_id"] = user_class
    return request


def check_if_auth_user(request):
    if request.session.has_key("user_mail_id"):
        return request.session["user_mail_id"]
    else:
        return None


def stop_user_session(request):
    if request.session.has_key("user_mail_id"):
        del request.session["user_mail_id"]
        del request.session["customer_id"]
        return True
    return False

import smtplib
import random
def send_mail(email_id):
    fromaddr = 'guptajape@gmail.com'
    toaddrs = email_id
    num=random.randrange(111111,999999)
    cursor = connection.cursor()
    query = "update Customer set otp = '%s' where email_id = '%s' " % (num, email_id)
    cursor.execute(query)
    msg = ("From: From Organiser <fashion jwellery>\n"
           "To: To Person <jayprakash.gupta.cse15@itbhu.ac.in>\n"
           "Subject: Welcome to Jwellery shop \n"
           "    \n"
           "This is your otp code :\n"
           "%s\n"
           "    ") % ( num)
    username = 'yourmail@gmail.com'
    password = 'yourpassword'
    print(msg)
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.ehlo()
    server.starttls()
    server.login(username, password)
    server.sendmail(fromaddr, toaddrs, msg)
    server.quit()



def homepage(request):

    return render (request, 'homepage.html',{'auth':check_if_auth_user(request)})

def confirm(request):
    if request.method == "POST":
        id = request.POST.get('id')
        code = request.POST.get('code')
        cursor = connection.cursor()
        query = "select otp from Customer where customer_id = %s"%id
        cursor.execute(query)
        results = cursor.fetchall()
        if results:
            if results[0][0]==code:
                query = "update Customer set confirm = 'confirm' where customer_id = %s" % id
                cursor.execute(query)
                query = "select email_id from Customer where customer_id = %s" % id
                cursor.execute(query)
                res=cursor.fetchall()
                try:
                    email=res[0][0]
                    start_user_session(request, email, id)
                    return redirect('/accounts/')
                except:
                    return render(request, 'confirm.html', {'id': id, 'error': True})
            else:
                return render(request, 'confirm.html', {'id': id,'error':True})
        else:
            return render(request, 'confirm.html', {'id': id, 'error': True})
    else:
        return redirect('/accounts/')


def login(request):
    if request.method == 'POST':
        # authenticate user
        email=request.POST.get('email')
        paw = request.POST.get('psw')
        if email and paw:
            cursor = connection.cursor()
            rec_pass = paw.encode('utf-8')
            var = hashlib.sha256(rec_pass + salt).hexdigest()
            query="select customer_id from Customer where email_id = \'"+str(email)+"\' ;"
            cursor.execute(query)
            results = cursor.fetchall()

            if results:
                query="select confirm from Customer where email_id = '%s' "%email
                cursor.execute(query)
                rr = cursor.fetchall()
                if rr:
                    if rr[0][0] == 'confirm':
                        start_user_session(request,email,results[0][0])
                        return redirect('/accounts/')
                    else:
                        return render(request,'confirm.html',{'id':results[0][0]})
                else:
                    send_mail(email)
                    return render(request, 'confirm.html', {'id': results[0][0]})
            else:

                return render(request,'login.html',{'error':True})
        else:
            return render(request, 'login.html', {'error': True})


    else:
        if check_if_auth_user(request):
            return redirect('./')
        return render(request, 'login.html')


def logout(request):
    stop_user_session(request)
    return redirect('/accounts/')

def signup(request):
    if request.method == 'POST':
        # authenticate user
        email=request.POST.get('email')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        add = request.POST.get('add')
        mob = request.POST.get('mob')
        paw = request.POST.get('psw')
        rec_pass = paw.encode('utf-8')
        var = hashlib.sha256(rec_pass + salt).hexdigest()

        if email and paw and fname and lname and add and mob:
            cursor = connection.cursor()
            query=""" select * from Customer where email_id = "%s" """%email
            cursor.execute(query)
            s=cursor.fetchall()
            if s :
                return render(request, 'signup.html', {'error': True,'msg':"Email is already used"})
            query = """ select * from Customer where mobile_number = %s """ %mob
            cursor.execute(query)
            s = cursor.fetchall()
            if s:
                return render(request, 'signup.html', {'error': True, 'msg': "Mob is already used"})
            query="""insert into Customer(first_name,last_name,password,mobile_number,email_id,address) 
                     values (
                     "%s","%s","%s",%d,"%s","%s")
            """%(fname,lname,var,int(mob),email,add)
            print(query)
            cursor.execute(query)
            send_mail(email)
            return redirect('/accounts/login')
        else:
            return render(request, 'signup.html', {'error': True})


    else:
        if check_if_auth_user(request):
            return redirect('./')
        return render(request, 'signup.html',{'auth':check_if_auth_user(request)})


def profile(request):
    email_id=check_if_auth_user(request)
    if email_id :
        cursor = connection.cursor()
        query = "select * from Customer where email_id = %s"
        cursor.execute(query,(email_id,))
        results = cursor.fetchall()
        return render(request,'profile.html',{'auth':check_if_auth_user(request),'results':results})
    else:
        return redirect("./login")

def profile_orders(request):
    email_id=check_if_auth_user(request)
    if email_id :
        cursor = connection.cursor()
        query = "select * from Customer where email_id = %s"
        cursor.execute(query, (email_id,))
        results = cursor.fetchall()
        cus_id=results[0][0]
        query = """select Orders.order_id, Stock.name_stock,
                          Stock.type_stock, Stock.weight,
                          Stock.tounch,Stock.price,
                          Orders.amount,Orders.date,Orders.status
                          ,Orders.expected_date, Orders.amount*Stock.price 
	                from Orders inner join  Stock on Orders.stock_id = Stock.stock_id 
	                where Orders.customer_id = %d 
        """%(cus_id)
        cursor.execute(query)
        order_detail=cursor.fetchall()
        query = """select sum( Orders.amount*Stock.price) 
        	       from Orders inner join  Stock on Orders.stock_id = Stock.stock_id 
        	       where Orders.customer_id = %d and Orders.status = 'pedding'
                """ % (cus_id)
        cursor.execute(query)
        ss = cursor.fetchall()
        total=0
        if  ss:
            total=ss[0][0]
        return render(request, 'profile.html', {'auth': check_if_auth_user(request),'data':order_detail, 'results': results,'total':total,'order_botton' : True })
    else:
        return redirect("./login")

def profile_edit(request):
    if request.method == 'POST' :
        email_id = check_if_auth_user(request)
        if email_id:
            fname = request.POST.get('fname')
            lname = request.POST.get('lname')
            mob = request.POST.get('mob')
            address = request.POST.get('address')
            ss = request.POST.get('psw')
            rec_pass = ss.encode('utf-8')
            psw = hashlib.sha256(rec_pass + salt).hexdigest()
            email = request.POST.get('email')
            cursor = connection.cursor()
            query="""update Customer set first_name = "%s" ,last_name = "%s", email_id = "%s",mobile_number = %s,address = "%s",password = "%s" where email_id = "%s" """%(fname,lname,email,mob,address,psw,email_id)
            cursor.execute(query)
            query = "select * from Customer where email_id = %s"
            cursor.execute(query, (email_id,))
            results = cursor.fetchall()
            return render(request, 'profile.html',
                          {'auth': check_if_auth_user(request), 'results': results, 'edit_botton': True})
        else:
            return redirect("./login")

    else:
        email_id = check_if_auth_user(request)
        if email_id:
            cursor = connection.cursor()
            query = "select * from Customer where email_id = %s"
            cursor.execute(query, (email_id,))
            results = cursor.fetchall()
            return render(request, 'profile.html',{'auth': check_if_auth_user(request), 'results': results,'edit_botton': True})
        else:
            return redirect("./login")


def profile_review(request):
    if request.method == 'POST' :
        email_id = check_if_auth_user(request)
        if email_id:
            customer = request.POST.get('customer')
            stock = request.POST.get('stock')
            star = request.POST.get('star')
            comment = request.POST.get('comment')
            try:
                cursor=connection.cursor()
                query=""" insert into Review( customer_id,stock_id,star,comment) values( %s,%s,%s,"%s") """%(customer,stock,star,comment)
                cursor.execute(query)
            except:
                cursor = connection.cursor()
                query = """ update Review set star = %s, comment = "%s"  where customer_id = %s and stock_id = %s """ % ( star, comment,customer, stock)
                cursor.execute(query)
            query = "select stock_id,name_stock from Stock"
            cursor.execute(query)
            data1 = cursor.fetchall()
            query = "select * from Customer where email_id = %s"
            cursor.execute(query, (email_id,))
            results = cursor.fetchall()
            return render(request, 'profile.html', {'auth': check_if_auth_user(request), 'results': results, 'review_botton': True,'data':data1})
        else:
            return redirect("./login")
    else:
        email_id = check_if_auth_user(request)
        if email_id:
            query = "select * from Customer where email_id = %s"
            cursor=connection.cursor()
            cursor.execute(query, (email_id,))
            results = cursor.fetchall()
            query = "select stock_id,name_stock from Stock"
            cursor.execute(query)
            data1 = cursor.fetchall()
            return render(request, 'profile.html',{'auth': check_if_auth_user(request), 'results': results, 'review_botton': True,'data':data1})
        else:
            return redirect("./login")

def pay(request):
    if request.method=='POST':
        id=request.POST.get('id')
        amount=request.POST.get('amount')
        cursor=connection.cursor()
        query = """update Orders set status = 'pay' where customer_id = %s   
                """ % (id)
        cursor.execute(query)
        return render(request,'pay.html',{'id':id,'amount':amount})
    else:
        return redirect("/accounts/")



