from django.shortcuts import render, redirect
from django.db import connection

def read_file(filename):
    with open(filename, 'rb') as f:
        photo = f.read()
    return photo


def write_file(data, filename):
    with open(filename, 'wb') as f:
        f.write(data)


# Create your views here.
def start_user_session(request, user_id):
    request.session["admin_id"] = user_id
    return request


def check_if_auth_user(request):
    if request.session.has_key("admin_id"):
        return request.session["admin_id"]
    else:
        return None


def stop_user_session(request):
    if request.session.has_key("admin_id"):
        del request.session["admin_id"]
        return True
    return False



def owner(request):
    if request.method == 'POST':
        # authenticate user
        email=request.POST.get('email')
        paw = request.POST.get('psw')
        if email and paw:
            cursor = connection.cursor()
            query="select * from Owner"
            cursor.execute(query)
            results = cursor.fetchall()

            if results[0][0] == email and results[0][1] == paw :
                start_user_session(request,email,)
                return redirect('/owner/')

            else:

                return render(request,'owner.html',{'error':True,'auth': check_if_auth_user(request)})
        else:
            return render(request, 'owner.html', {'error': True,'auth': check_if_auth_user(request)})


    else:
        return render(request, 'owner.html', {'auth': check_if_auth_user(request)})


def owner_logout(request):
    stop_user_session(request)
    return redirect('/owner/')



def stock_insert(request):
    if request.method == 'POST':
        # authenticate user
        sname = request.POST.get('name_stock')
        tstock = request.POST.get('type_stock')
        amount = request.POST.get('ava_amount')
        weight = request.POST.get('weight')
        tounch = request.POST.get('tounch')
        price = request.POST.get('price')
        data = request.FILES['photo'].read()

        if sname and tstock :
            cursor = connection.cursor()
            query="insert into Stock(name_stock,type_stock,weight,tounch,available_amount,price,photo) values(%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(query,(sname,tstock,weight,tounch,amount,price,data,))
            return render(request, 'owner.html', {'stk_insert':True,'msg':True,'auth': check_if_auth_user(request)})
        else:
            return render(request, 'owner.html', {'error': True,'auth': check_if_auth_user(request)})


    else:

        return render(request, 'owner.html', {'stk_insert': True,'auth': check_if_auth_user(request)})

def stock_show(request):
    if request.method=="POST":
        stock_id = request.POST.get('stock_id')
        cursor = connection.cursor()
        query= "delete from Stock where stock_id = %s"%stock_id
        cursor.execute(query)
        query = "select photo,stock_id from Stock"
        cursor.execute(query)
        results = cursor.fetchall()
        for i in range(0, len(results)):
            try:
                write_file(results[i][0], './owner/static/temp/img' + str(results[i][1]) + '.jpg')
            except:
                pass
        query = "select stock_id,name_stock,type_stock,price,available_amount,weight,tounch from Stock"
        cursor.execute(query)
        results = cursor.fetchall()
        dat = []
        for j in range(0, len(results)):
            dat.append(results[j] + ("./temp/img" + str(results[j][0]) + ".jpg",))
        data = tuple(dat)
        return render(request, 'owner.html', {'sk_show': True, 'auth': check_if_auth_user(request), 'data': data})

    else:
        cursor = connection.cursor()
        query = "select photo,stock_id from Stock"
        cursor.execute(query)
        results=cursor.fetchall()
        for i in range(0,len(results)):
            try :
                write_file(results[i][0], './owner/static/temp/img'+str(results[i][1])+'.jpg')
            except:
                pass
        query = "select stock_id,name_stock,type_stock,price,available_amount,weight,tounch from Stock"
        cursor.execute(query)
        results = cursor.fetchall()
        dat=[]
        for j in range(0,len(results)):
            dat.append(results[j]+("./temp/img"+str(results[j][0])+".jpg",))
        data=tuple(dat)
        return render(request,'owner.html',{'sk_show': True,'auth': check_if_auth_user(request),'data':data})


def emp_insert(request):
    if request.method == 'POST':
        # authenticate user
        ename = request.POST.get('name_emp')
        mob_no = request.POST.get('mob_no')
        salary = request.POST.get('salary')
        address = request.POST.get('address')


        if ename and mob_no:
            cursor = connection.cursor()
            try:
                query="""insert into Employee(name,mobile_number,salary,address) values("%s",%s,%s,"%s")"""%(ename,mob_no,salary,address)
                cursor.execute(query)
                return render(request, 'owner.html', {'emp_insert':True,'msg':True,'auth': check_if_auth_user(request)})
            except:
                return render(request, 'owner.html',{'emp_insert': True, 'msg': False, 'auth': check_if_auth_user(request)})
        else:
            return render(request, 'owner.html', {'error': True,'auth': check_if_auth_user(request)})
    else:

        return render(request, 'owner.html', {'emp_insert': True,'auth': check_if_auth_user(request)})

def emp_show(request):
    if request.method == "POST":
        name = request.POST.get('name_emp')
        salary = request.POST.get('salary')
        emp_id = request.POST.get('employee_id')
        address = request.POST.get('address')
        adv_money = request.POST.get('adv_money')
        no_of_leaves = request.POST.get('no_of_leaves')
        mob_no = request.POST.get('mob_no')
        work_id = request.POST.get('work_id')
        cursor = connection.cursor()
        query="""update Employee set name = "%s", mobile_number = %s,salary=%s,address="%s",
                 advance_money=%s,no_of_leaves = %s,work_id = %s where employee_id=%s
        """%(name,mob_no,salary,address,adv_money,no_of_leaves,work_id,emp_id)
        cursor.execute(query)
        query = """select employee_id,name,mobile_number,
                           salary,address,work_id,advance_money,join_date,no_of_leaves from Employee 
                           """
        cursor.execute(query)
        results = cursor.fetchall()
        return render(request, 'owner.html', {'emp_show': True, 'auth': check_if_auth_user(request), 'data': results})
    else:
        cursor = connection.cursor()
        query = """select employee_id,name,mobile_number,
                   salary,address,work_id,advance_money,join_date,no_of_leaves from Employee 
                   """
        cursor.execute(query)
        results=cursor.fetchall()
        return render(request,'owner.html',{'emp_show': True,'auth': check_if_auth_user(request),'data':results})

def raw_insert(request):
    if request.method == 'POST':
        # authenticate user
        sname = request.POST.get('name')
        amount = request.POST.get('amount')
        weight = request.POST.get('weight')
        price = request.POST.get('price')

        if sname :
            cursor = connection.cursor()
            query="insert into Raw_material(name,weight,price,avail_mat) values(%s,%s,%s,%s)"
            cursor.execute(query,(sname,weight,price,amount))
            return render(request, 'owner.html', {'raw_insert':True,'msg':True,'auth': check_if_auth_user(request)})
        else:
            return render(request, 'owner.html', {'error': True,'auth': check_if_auth_user(request)})
    else:
        return render(request, 'owner.html', {'raw_insert': True,'auth': check_if_auth_user(request)})

def raw_show(request):
    cursor = connection.cursor()
    if request.method=="POST":
        raw_id = request.POST.get('raw_id')
        query= "delete from Raw_material where raw_id = %s"%raw_id
        cursor.execute(query)
    query = "select raw_id,name,weight,price,avail_mat from Raw_material"
    cursor.execute(query)
    results = cursor.fetchall()
    return render(request, 'owner.html', {'raw_show': True, 'auth': check_if_auth_user(request), 'data': results})


def new_work(request):
    cursor = connection.cursor()
    if request.method == "POST":
        stock_id = request.POST.get('stock')
        raw=[]
        emp=[]
        raw.append(request.POST.get('raw1'))
        raw.append(request.POST.get('raw2'))
        raw.append( request.POST.get('raw3'))
        raw.append( request.POST.get('raw4'))
        raw.append( request.POST.get('raw5'))
        emp.append(request.POST.get('emp1'))
        emp.append(request.POST.get('emp2'))
        emp.append(request.POST.get('emp3'))
        emp.append(request.POST.get('emp4'))
        emp.append(request.POST.get('emp5'))
        print(raw,stock_id,emp)
        if stock_id != "select":
            query="insert into Work(stock_id) values(%s)"%(stock_id)
            cursor.execute(query)
            query="select work_id from Work where stock_id = %s and status = 'running' "%(stock_id)
            cursor.execute(query)
            res=cursor.fetchall()
            work_id=res[0][0]
            for i in range(0,5):
                if raw[i] !="select":
                    query="insert into raw_assign values( %s,%s)"%(raw[i],work_id)
                    try:
                        cursor.execute(query)
                    except:
                        pass
            for i in range(0,5):
                if emp[i]!="select":
                    query="update Employee set work_id = %s where employee_id = %s"%(work_id,emp[i])
                    try:
                        cursor.execute(query)
                    except:
                        pass
                    query="insert into hy (emp,wk) values(%s,%s)"%(emp[i],work_id)
                    try:
                        cursor.execute(query)
                    except:
                        pass
    query=""" select stock_id,name_stock from Stock where not exists ( select Work.stock_id from Work  where Stock.stock_id = Work.stock_id and Work.status = 'running' )"""
    cursor.execute(query)
    stock=cursor.fetchall()
    query = """ select employee_id,name from Employee where work_id = -1"""
    cursor.execute(query)
    emp = cursor.fetchall()
    query = """ select raw_id,name from Raw_material """
    cursor.execute(query)
    raw = cursor.fetchall()
    return render(request, 'owner.html', {'new_work': True, 'auth': check_if_auth_user(request), 'raw':raw,'stock':stock,'emp':emp,})


def edit_work(request):
    cursor = connection.cursor()
    if request.method == "POST":
        work_id=request.POST.get('work_id')
        raw=[]
        emp=[]
        raw.append(request.POST.get('raw1'))
        raw.append(request.POST.get('raw2'))
        raw.append( request.POST.get('raw3'))
        raw.append( request.POST.get('raw4'))
        raw.append( request.POST.get('raw5'))
        emp.append(request.POST.get('emp1'))
        emp.append(request.POST.get('emp2'))
        emp.append(request.POST.get('emp3'))
        emp.append(request.POST.get('emp4'))
        emp.append(request.POST.get('emp5'))
        dell=request.POST.get('del')
        if work_id :
            if not dell:
                for i in range(0,5):
                    if raw[i] !="select":
                        query="update  raw_assign set raw_id=%s where work_id = %s"%(raw[i],work_id)
                        try:
                            cursor.execute(query)
                        except:
                            pass
                query = "update Employee set work_id = -1 where work_id = %s " % (work_id)
                cursor.execute(query)
                query="delete from hy where wk = %s"%work_id
                cursor.execute(query)
                for i in range(0,5):
                    if emp[i]!="select":
                        query="update Employee set work_id = %s where employee_id = %s"%(work_id,emp[i])
                        try:
                            cursor.execute(query)
                        except:
                            pass
                        query = "insert into hy(wk,emp) values(%s,%s)" % (work_id,emp[i])
                        try:
                            cursor.execute(query)
                        except:
                            pass
            elif dell=='del':
                query = "update Employee set work_id = -1 where work_id = %s" % work_id
                cursor.execute(query)
                query = "update Work set status = 'aborted' where work_id = %s" % work_id
                cursor.execute(query)
            elif dell=='complete':
                query = "update Employee set work_id = -1 where work_id = %s" % work_id
                cursor.execute(query)
                query = "update Work set status = 'complete' where work_id = %s" % work_id
                cursor.execute(query)

    query=""" select Work.work_id,Stock.name_stock,Work.date from Work inner join Stock on Stock.stock_id = Work.stock_id where Work.status = 'running' order by Work.work_id"""
    cursor.execute(query)
    work_stock=cursor.fetchall()
    data=[]
    for i in range(0,len(work_stock)):
        query = """ select employee_id,name from Employee where work_id = %s"""%(work_stock[i][0])
        cursor.execute(query)
        emp=(cursor.fetchall())
        r1=[]
        for u in emp:
            r1.append(u)
        for y in range(len(r1),5):
            r1.append(("select","select"))

        query = """ select Raw_material.raw_id,Raw_material.name from Raw_material
               inner join raw_assign on raw_assign.raw_id = Raw_material.raw_id where
               raw_assign.work_id = %s""" % (work_stock[i][0])
        cursor.execute(query)
        raw=(cursor.fetchall())
        r2 = []
        for u in raw:
            r2.append(u)
        for y in range(len(r2), 5):
            r2.append(("select","select"))
        data.append([work_stock[i],r2,r1])
    query = """ select employee_id,name from Employee where work_id = -1"""
    cursor.execute(query)
    emp = cursor.fetchall()
    query = """ select raw_id,name from Raw_material """
    cursor.execute(query)
    raw = cursor.fetchall()
    return render(request, 'owner.html', {'edit_work': True, 'auth': check_if_auth_user(request), 'data':data,'raw':raw,'emp':emp,})




def show_work_history(request):
    cursor = connection.cursor()
    query=""" select Work.work_id,Stock.name_stock,Work.date,Work.status from Work inner join Stock on Stock.stock_id = Work.stock_id where Work.status != 'running' order by Work.work_id"""
    cursor.execute(query)
    work_stock=cursor.fetchall()
    data=[]
    for i in range(0,len(work_stock)):
        query = """ select Employee.employee_id,Employee.name from Employee inner join hy on Employee.employee_id = hy.emp where hy.wk = %s"""%(work_stock[i][0])
        cursor.execute(query)
        emp=(cursor.fetchall())
        r1=[]
        for u in emp:
            r1.append(u)
        for y in range(len(r1),5):
            r1.append((" "," "))

        query = """ select Raw_material.raw_id,Raw_material.name from Raw_material
               inner join raw_assign on raw_assign.raw_id = Raw_material.raw_id where
               raw_assign.work_id = %s""" % (work_stock[i][0])
        cursor.execute(query)
        raw=(cursor.fetchall())
        r2 = []
        for u in raw:
            r2.append(u)
        for y in range(len(r2), 5):
            r2.append((" "," "))
        data.append([work_stock[i],r2,r1])
    query = """ select employee_id,name from Employee where work_id = -1"""
    cursor.execute(query)
    emp = cursor.fetchall()
    query = """ select raw_id,name from Raw_material """
    cursor.execute(query)
    raw = cursor.fetchall()
    return render(request, 'owner.html', {'show_work': True, 'auth': check_if_auth_user(request), 'data':data,'raw':raw,'emp':emp,})

import datetime

def total_order(request):
    cursor = connection.cursor()
    if request.method=="POST":
        order_id=request.POST.get('order_id')
        date=request.POST.get('date')
        dat=datetime.datetime.strptime(date, "%m/%d/%Y").date()
        query="update Orders set expected_date = '%s' where order_id =%s"%(dat,order_id)
        cursor.execute(query)
    query = """select Orders.order_id, Stock.name_stock,
                      Stock.type_stock, Stock.weight,
                      Stock.tounch,Stock.price,
                      Orders.amount,Orders.date,Orders.status
                      ,Orders.customer_id,Orders.expected_date 
                from Orders inner join  Stock on Orders.stock_id = Stock.stock_id 
    """
    cursor.execute(query)
    order_detail=cursor.fetchall()
    return render(request, 'owner.html', {'auth': check_if_auth_user(request),'data':order_detail, 'order_botton' : True })


def dealer_insert(request):
    if request.method == 'POST':
        # authenticate user
        ename = request.POST.get('name')
        mob_no = request.POST.get('mob')
        email = request.POST.get('email')
        address = request.POST.get('address')


        if ename and mob_no:
            cursor = connection.cursor()
            try:
                query="""insert into Dealer(name,mobile_number,email,address) values("%s",%s,"%s","%s")"""%(ename,mob_no,email,address)
                cursor.execute(query)
                return render(request, 'owner.html', {'dealer_insert':True,'msg':True,'auth': check_if_auth_user(request)})
            except:
                return render(request, 'owner.html', {'dealer_insert':True,'msg':False,'auth': check_if_auth_user(request)})
        else:
            return render(request, 'owner.html', {'error': True,'auth': check_if_auth_user(request)})


    else:

        return render(request, 'owner.html', {'dealer_insert': True,'auth': check_if_auth_user(request)})


def dealer_show(request):
    if request.method == "POST":
        name = request.POST.get('name')
        dealer_id = request.POST.get('dealer_id')
        address = request.POST.get('address')
        mob_no = request.POST.get('mob')
        email = request.POST.get('email')
        cursor = connection.cursor()
        query="""update Dealer set name = "%s", mobile_number = %s,address="%s",
                 email = "%s" where dealer_id=%s
        """%(name,mob_no,address,email,dealer_id)
        cursor.execute(query)

    cursor = connection.cursor()
    query = """select dealer_id,name,mobile_number,
               email,address from Dealer 
               """
    cursor.execute(query)
    results=cursor.fetchall()
    return render(request,'owner.html',{'dealer_show': True,'auth': check_if_auth_user(request),'data':results})


def purchage(request):
    cursor = connection.cursor()
    if request.method == "POST":
        dealer_id = request.POST.get('dealer')
        query="insert into Purchage( dealer_id ) values(%s)"%dealer_id
        cursor.execute(query)
        cursor.execute('select max(purchage_id) from Purchage')
        res=cursor.fetchall()
        purchage_id=res[0][0]
        for i in range(1,11):
            raw=request.POST.get('raw'+str(i))
            amount = request.POST.get('amount' + str(i))
            if raw != "raw":
                query="insert into Pur_raw(raw_id,amount,purchage_id) values(%s,%s,%s)"%(raw,amount,purchage_id)
                cursor.execute(query)
                cursor.execute('update Raw_material set avail_mat = avail_mat + %s where raw_id = %s',(amount,raw) )
    query = """select dealer_id,name from Dealer """
    cursor.execute(query)
    dealer=cursor.fetchall()
    query = """select raw_id,name from Raw_material """
    cursor.execute(query)
    raw1 = cursor.fetchall()
    return render(request,'owner.html',{'purchage': True,'auth': check_if_auth_user(request),'dealer':dealer,'raw':raw1})


def purchage_show(request):
    cursor=connection.cursor()
    query = """select purchage_id,dealer_id,join_date from Purchage """
    cursor.execute(query)
    purch=cursor.fetchall()
    size=len(purch)
    data=[]
    for i in range(0,size):
        pur_id=purch[i][0]
        query="select Pur_raw.raw_id,Raw_material.name,Pur_raw.amount,Raw_material.price,(Pur_raw.amount*Raw_material.price) from Pur_raw inner join Raw_material on Raw_material.raw_id = Pur_raw.raw_id where Pur_raw.purchage_id =%s"%pur_id
        cursor.execute(query)
        p=cursor.fetchall()
        query = "select sum(Pur_raw.amount*Raw_material.price) from Pur_raw inner join Raw_material on Raw_material.raw_id = Pur_raw.raw_id where Pur_raw.purchage_id =%s" % pur_id
        cursor.execute(query)
        q = cursor.fetchall()
        data.append(purch[i]+(p,)+q[0])

    return render(request,'owner.html',{'purchage_show': True,'auth': check_if_auth_user(request),'data':data})

