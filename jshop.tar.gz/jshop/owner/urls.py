from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.owner, name='ownerpage'),
    url(r'^owner_logout$', views.owner_logout, name='logout_page'),
    url(r'^stock_insert$', views.stock_insert, name='stock_insert_page'),
    url(r'^stock_show$', views.stock_show, name='stock_show_page'),
    url(r'^emp_insert$', views.emp_insert, name='emp_insert_page'),
    url(r'^emp_show$', views.emp_show, name='emp_show_page'),
    url(r'^raw_insert$', views.raw_insert, name='raw_insert_page'),
    url(r'^raw_show$', views.raw_show, name='raw_show_page'),
    url(r'^new_work$', views.new_work, name='new_work_page'),
    url(r'^edit_work$', views.edit_work, name='edit_work_page'),
    url(r'^show_work_history$', views.show_work_history, name='show_work_page'),
    url(r'^total_order$', views.total_order, name='total_order_page'),
    url(r'^dealer_insert$', views.dealer_insert, name='dealer_insert_page'),
    url(r'^dealer_show$', views.dealer_show, name='dealer_show_page'),
    url(r'^purchage$', views.purchage, name='purchage_page'),
    url(r'^purchage_show$', views.purchage_show, name='purchage_show_page'),

]