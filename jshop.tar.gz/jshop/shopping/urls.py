from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^(?P<num>[0-9]+)/$', views.shopping, name='shoppingpage'),
]