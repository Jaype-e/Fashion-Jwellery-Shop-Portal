from django.shortcuts import render, redirect
from django.db import connection


# Create your views here.

def check_if_auth(request):
    if request.session.has_key("customer_id"):
        return request.session["customer_id"]
    else:
        return None

def check_if_auth_user(request):
    if request.session.has_key("user_mail_id"):
        return request.session["user_mail_id"]
    else:
        return None




def read_file(filename):
    with open(filename, 'rb') as f:
        photo = f.read()
    return photo


def write_file(data, filename):
    with open(filename, 'wb') as f:
        f.write(data)

def shopping(request,num):
    cursor = connection.cursor()
    msg=False
    mss=False
    if request.method=="POST":
        stock_id = request.POST.get('stock_id')
        amount = request.POST.get('amount')
        customer_id=check_if_auth(request)
        offer_code=request.POST.get('offer_code')
        query="select available_amount from Stock where stock_id = %s"%stock_id
        cursor.execute(query)
        res=cursor.fetchall()
        try:
            amp1=int(res[0][0])
            if( amp1 < int(amount)):
                msg=True
            else:
                query = "update Stock set available_amount = %s where stock_id = %s" % (amp1 - int(amount), stock_id)
                cursor.execute(query)
        except:
            msg=True
        if not msg:
            if not customer_id:
                return redirect('/accounts/login')
            if offer_code:
                query="insert into Orders(stock_id,amount,customer_id,offer_code) values( %d,%d,%d,\"%s\")"%(int(stock_id),int(amount),int(customer_id),offer_code)
                cursor.execute(query)
            else:
                query="insert into Orders(stock_id,amount,customer_id) values( %d,%d,%d)"%(int(stock_id),int(amount),int(customer_id))
                cursor.execute(query)
            mss=True

    query = "select photo,stock_id from Stock"
    cursor.execute(query)
    results=cursor.fetchall()
    number_stock = len(results)
    num_page = int( (number_stock+1) / 2 )
    cur_page=int(num)
    if cur_page > num_page:
        cur_page=num_page
    query = "select stock_id,name_stock,type_stock,price,available_amount,weight,tounch,photo from (select stock_id,name_stock,type_stock,price,available_amount,weight,tounch,photo from Stock order by stock_id limit %d ) as temp order by stock_id desc limit 2"%(int(num)*2)
    cursor.execute(query)
    results = cursor.fetchall()

    dat=[]
    page_dic=[]
    for j in range(num_page):
        page_dic.append(('/shopping/'+str(j+1),j+1))
    for j in range(0,len(results)):
        query = "select avg( star ) from Review where stock_id = %s group by stock_id " % (results[j][0])
        cursor.execute(query)
        p = cursor.fetchall()
        if not p :
            p=(('NA',),)
        dat.append(results[j]+(p[0][0],))
    data=tuple(dat)
    dic_={'page_no':cur_page,'data':data,'page_dic':page_dic,'auth': check_if_auth_user(request),'msg':msg,'mss':mss}
    return render(request,'shopping.html',dic_)

